package LULA_Sistema;

public class Main {
    public static void main(String[] args) {
        LULASistema sistema = new LULASistema();
        sistema.cadastraLocal("CAA", "Central de Aulas", "1122");
        sistema.cadastraLocal("BG", "Central de barcas", "5544");
        System.out.println(sistema.listaLocais());
    }
}
