package LULA_Sistema;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LULASistemaTest {
    private LULASistema sistemaTest;
    private Throwable exception;

    @BeforeEach
    void preparaSistema() {
        sistemaTest = new LULASistema();
    }

    @Test
    void cadastraLocal() {
    }

    @Test
    void cadastraLocalExceptions() {
    }

    @Test
    void cadastraComitiva() {
    }

    @Test
    void cadastraComitivaExceptions() {
    }

    @Test
    void exibeComitiva() {
    }

    @Test
    void exibeComitivaExceptions() {
    }

    @Test
    void exibeLocal() {
    }

    @Test
    void exibeLocalExceptions() {
    }
}